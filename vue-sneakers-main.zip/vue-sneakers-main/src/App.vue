<script setup>
import HomePage from './pages/Home.vue';
import Drawer from './components/Drawer.vue';
</script>

<template>
  <!-- <Drawer /> -->
  <HomePage />
</template>
